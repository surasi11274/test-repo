<?php $__env->startSection('page1'); ?>
<div class="container" style="margin-top:80px;text-align:center;">
    <h1>
  " <_ OUR PROJECT _> "
    </h1>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/Web_SNP/test-repo/Exhibition_web_interactive/resources/views/home/ourproject.blade.php ENDPATH**/ ?>