<?php $__env->startSection('page'); ?>

<!-- //OUR PROJECT -->
<!-- container -->
<div class ="container-fluid" style="margin-top:60px;"> 
    <div class="row">
            <!-- Menu -->
            <div class="col-lg-4 col-md-12 col-sm-12" style="background:red;"> OUR PROJECT</div>
            <div class="col-lg-4 col-md-12 col-sm-12" style="background:green;">------------------</div>
            <div class="col-lg-4 col-md-12 col-sm-12" style="background:blue;">
                <div class="row">
                        <div class="col-lg-12 col-md-4 col-sm-4">
                            MOBILE
                        </div>
                        <div class="col-lg-12 col-md-4 col-sm-4">
                            MOBILE
                        </div>
                        <div class="col-lg-12 col-md-4 col-sm-4">
                            MOBILE
                        </div> 
                </div>
            </div>
            <!-- Menu -->

            <!-- Project -->
            <div class="container-fluid" style="padding:20px;">
                <div class="row">
                    
                <div class="col-lg-3 col-md-3 col-sm-12">
                            <div class="card" >
                            <img class="card-img-top" src="https://encrypted-tbn0.gstatic.com/images?q=tbn%3AANd9GcRDje8CuBnO05WU1L4nRA0X-nw6UAtwaMBsvR1RdayUNBfP7rhk&usqp=CAU" alt="Card image cap">
                            <div class="card-body">
                                <h5 class="card-title">Card title</h5>
                                <p class="card-text">Some quick example text to build on the card title and make up the bulk of the card's content.</p>
                                <a href="#" class="btn btn-primary">Go somewhere</a>
                            </div>
                            </div>
                        </div>

                        <div class="col-lg-3 col-md-3 col-sm-12">
                            <div class="card" >
                            <img class="card-img-top" src="https://encrypted-tbn0.gstatic.com/images?q=tbn%3AANd9GcRDje8CuBnO05WU1L4nRA0X-nw6UAtwaMBsvR1RdayUNBfP7rhk&usqp=CAU" alt="Card image cap">
                            <div class="card-body">
                                <h5 class="card-title">Card title</h5>
                                <p class="card-text">Some quick example text to build on the card title and make up the bulk of the card's content.</p>
                                <a href="#" class="btn btn-primary">Go somewhere</a>
                            </div>
                            </div>
                        </div>


                        <div class="col-lg-3 col-md-3 col-sm-12">
                            <div class="card" >
                            <img class="card-img-top" src="https://encrypted-tbn0.gstatic.com/images?q=tbn%3AANd9GcRDje8CuBnO05WU1L4nRA0X-nw6UAtwaMBsvR1RdayUNBfP7rhk&usqp=CAU" alt="Card image cap">
                            <div class="card-body">
                                <h5 class="card-title">Card title</h5>
                                <p class="card-text">Some quick example text to build on the card title and make up the bulk of the card's content.</p>
                                <a href="#" class="btn btn-primary">Go somewhere</a>
                            </div>
                            </div>
                        </div>

                        <div class="col-lg-3 col-md-3 col-sm-12">
                            <div class="card" >
                            <img class="card-img-top" src="https://encrypted-tbn0.gstatic.com/images?q=tbn%3AANd9GcRDje8CuBnO05WU1L4nRA0X-nw6UAtwaMBsvR1RdayUNBfP7rhk&usqp=CAU" alt="Card image cap">
                            <div class="card-body">
                                <h5 class="card-title">Card title</h5>
                                <p class="card-text">Some quick example text to build on the card title and make up the bulk of the card's content.</p>
                                <a href="#" class="btn btn-primary">Go somewhere</a>
                            </div>
                            </div>
                        </div>
                    </div>
                </div>
            <!-- Project -->

            <!-- //Creator -->
            <div style="padding:60px;">
                        <h1 style="text-align:center;"> " <_ NEWS_  &  _ARTICLES _> " </h1>
                        <br>
                        <div class="row mt-4">
                                <div class="col-lg-4 col-md-6 col-sm-12">
                                    <div class="card" >
                                            <img class="card-img-top" src="https://encrypted-tbn0.gstatic.com/images?q=tbn%3AANd9GcRDje8CuBnO05WU1L4nRA0X-nw6UAtwaMBsvR1RdayUNBfP7rhk&usqp=CAU" alt="Card image cap">
                                            <div class="card-body">
                                                <h5 class="card-title">Card title</h5>
                                                <p class="card-text">Some quick example text to build on the card title and make up the bulk of the card's content.</p>
                                                <a href="#" class="btn btn-primary">Go somewhere</a>
                                            </div>
                                        </div>
                                    </div>

                                    <div class="col-lg-4 col-md-6 col-sm-12">
                                        <div class="card" >
                                            <img class="card-img-top" src="https://encrypted-tbn0.gstatic.com/images?q=tbn%3AANd9GcRDje8CuBnO05WU1L4nRA0X-nw6UAtwaMBsvR1RdayUNBfP7rhk&usqp=CAU" alt="Card image cap">
                                            <div class="card-body">
                                                <h5 class="card-title">Card title</h5>
                                                <p class="card-text">Some quick example text to build on the card title and make up the bulk of the card's content.</p>
                                                <a href="#" class="btn btn-primary">Go somewhere</a>
                                            </div>
                                        </div>
                                    </div>

                                    <div class="col-lg-4 col-md-6 col-sm-12">
                                        <div class="card" >
                                            <img class="card-img-top" src="https://encrypted-tbn0.gstatic.com/images?q=tbn%3AANd9GcRDje8CuBnO05WU1L4nRA0X-nw6UAtwaMBsvR1RdayUNBfP7rhk&usqp=CAU" alt="Card image cap">
                                            <div class="card-body">
                                                <h5 class="card-title">Card title</h5>
                                                <p class="card-text">Some quick example text to build on the card title and make up the bulk of the card's content.</p>
                                                <a href="#" class="btn btn-primary">Go somewhere</a>
                                            </div>
                                        </div>
                                    </div>
                            </div>
                        </div>
                </div>
             <!-- //Creator -->
        </div> <!-- row -->
</div>  <!-- container -->

            <br>
            <br>
            <br>
            <br>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/Web_SNP/test-repo/Exhibition_web_interactive/resources/views/home/Home.blade.php ENDPATH**/ ?>