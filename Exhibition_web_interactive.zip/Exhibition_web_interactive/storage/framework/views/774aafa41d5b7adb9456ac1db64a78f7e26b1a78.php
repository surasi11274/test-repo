<?php $__env->startSection('page'); ?>
<!-- content -->
<div class="container" style="margin-top:100px;">
    <form action="/createContentComplete" enctype="multipart/form-data" method="POST">
        <?php echo e(csrf_field()); ?>

        <div class="form-group">
            <label for="exampleInputEmail1">Header</label>
            <input class="form-control" name="header" aria-describedby="emailHelp" placeholder="Header">
            <small id="emailHelp" class="form-text text-muted">We'll never share your email with anyone else.</small>
        </div>
        <div class="form-group">
            <label for="exampleInputPassword1">Title</label>
            <input class="form-control" name="title" placeholder="Title">
        </div>

        <div class="form-group">
            <label for="exampleInputEmail1">Category</label>
            <input class="form-control" name="category" aria-describedby="emailHelp" placeholder="Category">
            <small id="emailHelp" class="form-text text-muted">We'll never share your email with anyone else.</small>
        </div>
        <div class="form-group">
            <label for="exampleInputPassword1">Content</label>
            <input class="form-control" name="content" placeholder="Content">
        </div>

        <div class="form-group">
            <label for="exampleInputEmail1">Credit</label>
            <input class="form-control" name="credit" aria-describedby="emailHelp" placeholder="Credit">
            <small id="emailHelp" class="form-text text-muted">We'll never share your email with anyone else.</small>
        </div>

        <div class="form-group">
            <label for="exampleFormControlFile1">Image</label>
            <input type="file" class="form-control-file" name="image">
        </div>

    <button type="submit" class="btn btn-primary">Submit</button>
    </form>
        <div class="mt-4">
            <?php if($errors->any()): ?>  
                <div>
                    <ul>
                    <?php $__currentLoopData = $errors  ->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li><?php echo e($error); ?></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                </div>
            <?php endif; ?> 
        </div>
 </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/Web_SNP/test-repo/Exhibition_web_interactive/resources/views/Content/create.blade.php ENDPATH**/ ?>