<style>
.footerpage {
   position: fixed;
   left: 0;
   bottom: 0;
   width: 100%;
   color: black;
   text-align: center;
   background-color: #fff;
   border-color: rgba(231, 231, 231, 0);
   box-shadow: 0 0 10px rgba(0,0,0,0.15);
   padding:10px;
}
</style>

    <div class="footerpage" style="text-align: center;">
            <h1> @ FOOTER </h1>
            <h2>with sponsers</h2>
    </div>
   
